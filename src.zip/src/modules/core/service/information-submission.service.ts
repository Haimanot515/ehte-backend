import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';

import { EventEmitter2 } from '@nestjs/event-emitter';
import { ConfigService } from '@nestjs/config';

import {
  AuditOutcome,
  AuditSeverity,
  InformationStatus,
  MissingPersonStatus,
} from '@prisma/client';

import { PrismaService } from 'src/prisma/prisma.service';
import { CurrentUserDto } from 'src/common/dtos/current-user.dto';
import { resolveActorType } from 'src/common/utils/actor-type.util';

import { AuditEventEnum } from 'src/common/enums/shared/audit-events.enum';
import { AuditEventPayload } from 'src/modules/misc/events/audit.events';
import { NotificationEventEnum } from 'src/common/enums/shared/notification-events.enum';

import { MinioService } from 'src/services/minio/minio.service';
import { CacheService } from 'src/services/redis/cache.service';

import {
  CreateInformationSubmissionDto,
  ListInformationSubmissionsQueryDto,
  UpdateInformationSubmissionDto,
} from '../dto/information-submission.dto';

// Media array fields shared by the DTOs and the InformationSubmission model.
const MEDIA_FIELD_NAMES = ['photo', 'video', 'audio', 'pdf', 'document', 'other'] as const;
type MediaFieldName = (typeof MEDIA_FIELD_NAMES)[number];
type MediaBearing = Record<MediaFieldName, string[]>;
type MediaBearingDto = Partial<Record<MediaFieldName, string[] | undefined>>;

// ⚠️ ASSUMPTIONS ON THE AUDIT ENUM
//
// Two action names are referenced below that this file didn't
// previously import: AuditEventEnum.INFORMATION_SUBMISSION_UPDATED
// and AuditEventEnum.INFORMATION_SUBMISSION_MEDIA_DOWNLOADED. Every
// other service in this codebase follows a <Entity>_<VERB> naming
// convention for its audit actions (REPORT_UPDATED, REPORT_MEDIA_
// DOWNLOADED, USER_UPDATED, SUPPORT_CANCELLED, ...), so these are
// assumed to exist or to be trivial additions to the shared enum. If
// they don't exist yet, add them there rather than repurposing an
// unrelated action name — reusing e.g. INFORMATION_SUBMITTED for an
// edit would make "who submitted this" and "who edited this" show up
// as the same action in a history view.
//
// ⚠️ ASSUMPTION ON THE CACHE SERVICE
//
// Same convention as MissingPersonService/PostService: getX/setX for
// a single cached row, wrapXList for a paginated/filterable list, and
// invalidateXList (rather than invalidateXEverywhere) since — unlike
// Post/MissingPerson — no single-submission public read exists here
// to invalidate, only the list.

@Injectable()
export class InformationSubmissionService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly eventEmitter: EventEmitter2,
    private readonly minioService: MinioService,
    private readonly configService: ConfigService,
    private readonly cache: CacheService,
  ) {}

  // ─────────────────────────────────────────────
  // Admin workflow.
  //
  //   PENDING → UNDER_REVIEW           (updateStatus)
  //   UNDER_REVIEW → REVIEWED|REJECTED (review — terminal)
  //   REVIEWED → (final)
  //   REJECTED → (final)
  //
  // Both REVIEWED and REJECTED are terminal — there is no transition
  // back out of either. That matters for caching below: since
  // REVIEWED is the only status findForMissingPerson() ever serves,
  // and nothing can ever leave REVIEWED once it gets there, a
  // submission can only ever enter the cached public list once and
  // never has to be invalidated OUT of it — unlike Post (PUBLISHED
  // <-> UNPUBLISHED) or MissingPerson, which both need bidirectional
  // invalidation.
  // ─────────────────────────────────────────────

  private readonly ALLOWED_STATUS_TRANSITIONS: Record<InformationStatus, InformationStatus[]> = {
    [InformationStatus.PENDING]: [InformationStatus.UNDER_REVIEW],
    [InformationStatus.UNDER_REVIEW]: [],
    [InformationStatus.REVIEWED]: [],
    [InformationStatus.REJECTED]: [],
  };

  private emitAudit(payload: AuditEventPayload): void {
    this.eventEmitter.emit(payload.action, payload);
  }

  private getRoles(user: CurrentUserDto): string[] {
    return (user as unknown as { roles?: string[] }).roles ?? [];
  }

  // Labels by the missing-person case the tip is about, falling back to a snippet or id.
  private buildSubmissionLabel(
    submission: { id: string; information: string },
    missingPersonName?: string | null,
  ): string {
    if (missingPersonName) {
      return `Tip re: ${missingPersonName}`;
    }
    const snippet = submission.information.trim().slice(0, 40);
    if (snippet) {
      return snippet.length < submission.information.trim().length ? `${snippet}…` : snippet;
    }
    return `submission:${submission.id.slice(0, 8)}`;
  }

  private collectMediaFields(entity: MediaBearing): string[] {
    return MEDIA_FIELD_NAMES.flatMap((field) => entity[field]);
  }

  private collectMediaFieldsFromDto(dto: MediaBearingDto): string[] {
    return MEDIA_FIELD_NAMES.flatMap((field) => dto[field] ?? []);
  }

  // Diffs each media field individually so resending the same array isn't a remove+re-add.
  private diffMediaFields(
    before: MediaBearing,
    incoming: MediaBearingDto,
  ): { added: string[]; removed: string[] } {
    const added: string[] = [];
    const removed: string[] = [];

    for (const field of MEDIA_FIELD_NAMES) {
      const next = incoming[field];
      if (next === undefined) continue;
      const prev = before[field];
      added.push(...next.filter((fp) => !prev.includes(fp)));
      removed.push(...prev.filter((fp) => !next.includes(fp)));
    }

    return { added, removed };
  }

  // Confirms every new filepath exists in the media bucket and is within size/type limits.
  private async validateMediaFilesExist(
    filepaths: string[],
  ): Promise<Array<{ filepath: string; size: number }>> {
    if (!filepaths.length) return [];

    const maxFileSizeBytes = Number(
      this.configService.get<string>('MEDIA_MAX_FILE_SIZE') ?? 52_428_800,
    );
    const allowedMimeTypes = new Set(
      (this.configService.get<string>('MEDIA_ALLOWED_MIME_TYPES') ?? '')
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
    );

    const checks = await Promise.all(
      filepaths.map(async (filepath) => {
        const exists = await this.minioService.objectExists(filepath);
        if (!exists) {
          return { filepath, ok: false as const, reason: 'not_found', size: 0 };
        }

        const stat = await this.minioService.statObject(filepath);

        if (stat.size > maxFileSizeBytes) {
          return { filepath, ok: false as const, reason: 'too_large', size: stat.size };
        }
        if (allowedMimeTypes.size > 0 && !allowedMimeTypes.has(stat.contentType)) {
          return { filepath, ok: false as const, reason: 'disallowed_type', size: stat.size };
        }
        return { filepath, ok: true as const, size: stat.size };
      }),
    );

    const bad = checks.filter((c) => !c.ok);
    if (bad.length) {
      throw new BadRequestException(
        `media_validation_failed:${bad.map((b) => `${b.filepath}:${b.reason}`).join(',')}`,
      );
    }

    return checks.map((c) => ({ filepath: c.filepath, size: c.size }));
  }

  // Per-field attachment caps, checked before any MinIO round trips.
  private assertAttachmentCounts(media: MediaBearing): void {
    const maxPhotos = Number(
      this.configService.get<string>('INFORMATION_SUBMISSION_MAX_PHOTOS') ??
        this.configService.get<string>('CONTENT_MAX_PHOTOS') ??
        5,
    );
    const maxVideos = Number(
      this.configService.get<string>('INFORMATION_SUBMISSION_MAX_VIDEOS') ??
        this.configService.get<string>('CONTENT_MAX_VIDEOS') ??
        1,
    );
    const maxOther = Number(
      this.configService.get<string>('INFORMATION_SUBMISSION_MAX_OTHER_FILES') ??
        this.configService.get<string>('CONTENT_MAX_OTHER_FILES') ??
        2,
    );

    if (media.photo.length > maxPhotos) {
      throw new BadRequestException(`too_many_photos:max_${maxPhotos}`);
    }
    if (media.video.length > maxVideos) {
      throw new BadRequestException(`too_many_videos:max_${maxVideos}`);
    }
    const otherCount =
      media.audio.length + media.pdf.length + media.document.length + media.other.length;
    if (otherCount > maxOther) {
      throw new BadRequestException(`too_many_other_files:max_${maxOther}`);
    }
  }

  // Total attached-media size cap per submission.
  private assertTotalBytes(totalBytes: number): void {
    const maxTotalBytes = Number(
      this.configService.get<string>('INFORMATION_SUBMISSION_MAX_TOTAL_UPLOAD_BYTES') ??
        this.configService.get<string>('CONTENT_MAX_TOTAL_UPLOAD_BYTES') ??
        52_428_800,
    );
    if (totalBytes > maxTotalBytes) {
      throw new BadRequestException(`upload_total_size_exceeded:max_${maxTotalBytes}`);
    }
  }

  // Best-effort delete; a failure here must never block the DB write that triggered it.
  private async deleteMediaFiles(filepaths: string[]): Promise<void> {
    if (!filepaths.length) return;
    await Promise.allSettled(filepaths.map((fp) => this.minioService.deleteFile(fp)));
  }

  // Owner-facing download; not audited, same as ReportService's reporter-facing equivalent.
  async getMediaDownloadUrl(id: string, userId: string, key: string): Promise<{ url: string }> {
    const submission = await this.prisma.informationSubmission.findUnique({
      where: { id },
    });

    if (!submission) {
      throw new NotFoundException('information_submission_not_found');
    }

    if (submission.userId !== userId) {
      throw new ForbiddenException('not_authorized');
    }

    const owned = this.collectMediaFields(submission).includes(key);
    if (!owned) {
      throw new NotFoundException('media_not_found_on_submission');
    }

    const url = await this.minioService.generatePresignedDownloadUrl(key);
    return { url };
  }

  // Admin download; a mismatched key emits DENIED before throwing, success is logged too.
  async getMediaDownloadUrlForAdmin(
    admin: CurrentUserDto,
    id: string,
    key: string,
  ): Promise<{ url: string }> {
    const submission = await this.prisma.informationSubmission.findUnique({
      where: { id },
    });

    if (!submission) {
      throw new NotFoundException('information_submission_not_found');
    }

    const actorType = resolveActorType(this.getRoles(admin));
    const label = this.buildSubmissionLabel(submission);

    const owned = this.collectMediaFields(submission).includes(key);
    if (!owned) {
      this.emitAudit({
        userId: admin.id,
        targetUserId: submission.userId,
        actorType,
        action: AuditEventEnum.INFORMATION_SUBMISSION_MEDIA_DOWNLOADED,
        outcome: AuditOutcome.DENIED,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: submission.id,
        entityLabel: label,
        diff: { result: 'denied', reason: 'media_not_found_on_submission' },
        metadata: { requestedKey: key },
      });
      throw new NotFoundException('media_not_found_on_submission');
    }

    const url = await this.minioService.generatePresignedDownloadUrl(key);

    this.emitAudit({
      userId: admin.id,
      targetUserId: submission.userId,
      actorType,
      action: AuditEventEnum.INFORMATION_SUBMISSION_MEDIA_DOWNLOADED,
      entity: 'InformationSubmission',
      entityId: submission.id,
      entityLabel: label,
      diff: { result: 'success' },
      metadata: { key },
    });

    return { url };
  }

  // ─────────────────────────────────────────────
  // PUBLIC — MEDIA DOWNLOAD URL
  // GET /information-submissions/public/:id/media?key=...
  //
  // Media on a submission is only reachable once it has been
  // REVIEWED. A submission that exists but isn't reviewed yet
  // 404s here, not a different error shape.
  //
  // Deliberately NOT read through the cache: like
  // Post.getPublicMediaDownloadUrl, this is a narrow per-key lookup
  // rather than the whole public row, and MinIO presigned URLs are
  // already short-lived and cheap to mint.
  // ─────────────────────────────────────────────

  async getPublicMediaDownloadUrl(id: string, key: string): Promise<{ url: string }> {
    const submission = await this.prisma.informationSubmission.findFirst({
      where: {
        id,
        status: InformationStatus.REVIEWED,
      },
      select: {
        photo: true,
        video: true,
        audio: true,
        pdf: true,
        document: true,
        other: true,
      },
    });

    if (!submission) {
      throw new NotFoundException('information_submission_not_found');
    }

    const owned = this.collectMediaFields(submission).includes(key);
    if (!owned) {
      throw new NotFoundException('media_not_found_on_submission');
    }

    const url = await this.minioService.generatePresignedDownloadUrl(key);
    return { url };
  }

  // ─────────────────────────────────────────────
  // CREATE INFORMATION
  // Only allowed against APPROVED (publicly visible) cases, and
  // not by the person who filed the missing-person report itself.
  //
  // A freshly created submission is always PENDING — never REVIEWED,
  // the only status the public cache holds — so there's nothing to
  // invalidate here.
  //
  // FIX (item #1): per-user cooldown between submissions, plus a
  // cap on how many of a user's submissions can sit in
  // PENDING/UNDER_REVIEW at once — collapsed into one step here
  // since Information Submission has no separate draft→submit
  // flow the way Post does.
  //
  // FIX (item #5): optional Idempotency-Key lets a client safely
  // retry a create call after a dropped response — a repeat with
  // the same key returns the original submission instead of
  // creating a duplicate.
  //
  // FIX (item #13): attachment counts checked before any MinIO
  // round trips; total size persisted as mediaTotalBytes.
  //
  // FIX (audit review, item #1): actorType was hardcoded to
  // resolveActorType(['USER']) rather than resolved from the actual
  // submitter's roles — a plain typo-shaped bug (every other create()
  // in this codebase resolves from the real actor). It's now resolved
  // properly, which requires the actor's roles, so this method now
  // takes the full CurrentUserDto instead of a bare userId.
  //
  // ⚠️ SIGNATURE CHANGE: create(user: CurrentUserDto, ...) instead of
  // create(userId: string, ...). Update the controller accordingly.
  //
  // FIX (audit review, item #1, continued): every guard below —
  // not-approved, self-submission, rate limit, max-pending, media
  // validation — threw with no audit row. The not-approved and
  // self-submission guards run after the MissingPerson is loaded, so
  // both now emit against entity: 'MissingPerson' (there's no
  // InformationSubmission row yet to attach to). Deliberately NOT
  // fixed: missing_person_not_found itself, and the rate-limit/max-
  // pending/media-validation failures, for the same reason
  // ReportService.create() leaves its pre-creation guards unaudited —
  // no natural entity to hang the row on without a schema/product
  // decision on nullable entityIds.
  //
  // FIX (audit review, item #2): cannot_submit_information_on_own_report
  // is a user attempting to act on THEIR OWN missing-person report by
  // routing through the tip pathway — the missing person's owner
  // (i.e. the actor themselves here) is recorded as targetUserId for
  // consistency with how every other "acting on a record tied to a
  // user" case is audited elsewhere, even though actor and subject
  // are the same person in this specific case.
  //
  // FIX (audit review, item #4): entityLabel added, via the
  // already-loaded missingPerson's name.
  //
  // FIX (audit review, item #5): missingPersonId, attachment count,
  // and mediaTotalBytes are the investigative context worth keeping
  // and weren't captured before — moved into metadata.
  // ─────────────────────────────────────────────

  private async enforceCreateRateLimit(userId: string): Promise<void> {
    const cooldownSeconds = Number(
      this.configService.get<string>('INFORMATION_SUBMISSION_CREATE_RATE_LIMIT_WINDOW_SECONDS') ??
        this.configService.get<string>('CONTENT_CREATE_RATE_LIMIT_WINDOW_SECONDS') ??
        60,
    );

    const last = await this.prisma.informationSubmission.findFirst({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      select: { createdAt: true },
    });

    if (last && Date.now() - last.createdAt.getTime() < cooldownSeconds * 1000) {
      throw new BadRequestException('information_submission_rate_limited');
    }
  }

  private async enforceMaxPending(userId: string): Promise<void> {
    const maxPending = Number(
      this.configService.get<string>('INFORMATION_SUBMISSION_MAX_PENDING_PER_USER') ??
        this.configService.get<string>('CONTENT_MAX_PENDING_PER_USER') ??
        5,
    );

    const pendingCount = await this.prisma.informationSubmission.count({
      where: {
        userId,
        status: { in: [InformationStatus.PENDING, InformationStatus.UNDER_REVIEW] },
      },
    });

    if (pendingCount >= maxPending) {
      throw new BadRequestException('too_many_pending_information_submissions');
    }
  }

  // Only allowed against APPROVED cases, and not by the case's own reporter.
  async create(
    user: CurrentUserDto,
    missingPersonId: string,
    data: CreateInformationSubmissionDto,
    idempotencyKey?: string,
  ) {
    const actorType = resolveActorType(this.getRoles(user));

    if (idempotencyKey) {
      const existing = await this.prisma.informationSubmission.findFirst({
        where: { userId: user.id, idempotencyKey },
      });
      if (existing) {
        return existing;
      }
    }

    const missingPerson = await this.prisma.missingPerson.findUnique({
      where: { id: missingPersonId },
    });

    if (!missingPerson) {
      throw new NotFoundException('missing_person_not_found');
    }

    if (missingPerson.status !== MissingPersonStatus.APPROVED) {
      this.emitAudit({
        userId: user.id,
        actorType,
        action: AuditEventEnum.INFORMATION_SUBMITTED,
        outcome: AuditOutcome.FAILURE,
        severity: AuditSeverity.WARNING,
        entity: 'MissingPerson',
        entityId: missingPersonId,
        entityLabel: missingPerson.name ?? undefined,
        diff: {
          result: 'failure',
          reason: 'information_submission_not_allowed',
          missingPersonStatus: missingPerson.status,
        },
      });
      throw new BadRequestException('information_submission_not_allowed');
    }

    if (missingPerson.userId === user.id) {
      this.emitAudit({
        userId: user.id,
        targetUserId: missingPerson.userId,
        actorType,
        action: AuditEventEnum.INFORMATION_SUBMITTED,
        outcome: AuditOutcome.DENIED,
        severity: AuditSeverity.WARNING,
        entity: 'MissingPerson',
        entityId: missingPersonId,
        entityLabel: missingPerson.name ?? undefined,
        diff: { result: 'denied', reason: 'cannot_submit_information_on_own_report' },
      });
      throw new ForbiddenException('cannot_submit_information_on_own_report');
    }

    await this.enforceCreateRateLimit(user.id);
    await this.enforceMaxPending(user.id);

    const merged: MediaBearing = {
      photo: data.photo ?? [],
      video: data.video ?? [],
      audio: data.audio ?? [],
      pdf: data.pdf ?? [],
      document: data.document ?? [],
      other: data.other ?? [],
    };
    this.assertAttachmentCounts(merged);

    const validated = await this.validateMediaFilesExist(this.collectMediaFields(merged));
    const totalBytes = validated.reduce((sum, v) => sum + v.size, 0);
    this.assertTotalBytes(totalBytes);

    const submission = await this.prisma.informationSubmission.create({
      data: {
        userId: user.id,
        missingPersonId,

        information: data.information,
        location: data.location,

        photo: merged.photo,
        video: merged.video,
        audio: merged.audio,
        pdf: merged.pdf,
        document: merged.document,
        other: merged.other,
        mediaTotalBytes: totalBytes,

        status: InformationStatus.PENDING,
        idempotencyKey: idempotencyKey ?? null,
      },
    });

    this.emitAudit({
      userId: user.id,
      actorType,
      action: AuditEventEnum.INFORMATION_SUBMITTED,
      entity: 'InformationSubmission',
      entityId: submission.id,
      entityLabel: this.buildSubmissionLabel(submission, missingPerson.name),
      diff: {
        status: InformationStatus.PENDING,
        result: 'success',
      },
      metadata: {
        missingPersonId,
        attachmentCount: this.collectMediaFields(merged).length,
        mediaTotalBytes: totalBytes,
      },
    });

    this.eventEmitter.emit(NotificationEventEnum.NEW_MISSING_PERSON_INFORMATION, {
      missingPersonId,
      informationSubmissionId: submission.id,
      userId: user.id,
    });

    return submission;
  }

  // ─────────────────────────────────────────────
  // GET MY SUBMISSIONS (paginated)
  // Owner-scoped, not public — no cache.
  // ─────────────────────────────────────────────

  async findMine(userId: string, query: ListInformationSubmissionsQueryDto) {
    const page = query.page ?? 1;
    const limit = query.limit ?? 20;

    const where = { userId, ...(query.status !== undefined ? { status: query.status } : {}) };

    const [data, total] = await this.prisma.$transaction([
      this.prisma.informationSubmission.findMany({
        where,
        include: {
          missingPerson: {
            select: { id: true, personType: true, name: true, status: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.informationSubmission.count({ where }),
    ]);

    return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  // ─────────────────────────────────────────────
  // GET SUBMISSIONS FOR MISSING PERSON (public, paginated)
  //
  // The one genuinely public, anonymous-callable read in this file —
  // no CurrentUserDto, already status-gated to REVIEWED, and the
  // select already excludes userId/reviewNote/idempotencyKey/etc., so
  // there's nothing internal left in the cached shape to leak. Same
  // read-through pattern as MissingPersonService.findAll/findAllUncached
  // and PostService.findPublishedPosts/findPublishedPostsUncached: the
  // cache key is derived from (missingPersonId, query), and the DB path
  // only runs on a miss.
  //
  // Invalidated from review() below, and ONLY there — see the
  // ALLOWED_STATUS_TRANSITIONS comment above for why entering REVIEWED
  // is the only transition that can ever change what this returns.
  // ─────────────────────────────────────────────

  async findForMissingPerson(missingPersonId: string, query: ListInformationSubmissionsQueryDto) {
    return this.cache.wrapInformationSubmissionList(
      missingPersonId,
      query as unknown as Record<string, unknown>,
      () => this.findForMissingPersonUncached(missingPersonId, query),
    );
  }

  private async findForMissingPersonUncached(
    missingPersonId: string,
    query: ListInformationSubmissionsQueryDto,
  ) {
    const missingPerson = await this.prisma.missingPerson.findUnique({
      where: { id: missingPersonId },
    });

    if (!missingPerson) {
      throw new NotFoundException('missing_person_not_found');
    }

    const page = query.page ?? 1;
    const limit = query.limit ?? 20;

    const where = {
      missingPersonId,
      status: { in: [InformationStatus.REVIEWED] },
    };

    const [data, total] = await this.prisma.$transaction([
      this.prisma.informationSubmission.findMany({
        where,
        select: {
          id: true,
          information: true,
          location: true,
          photo: true,
          video: true,
          audio: true,
          pdf: true,
          document: true,
          other: true,
          status: true,
          createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.informationSubmission.count({ where }),
    ]);

    return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  // ─────────────────────────────────────────────
  // GET MY SUBMISSIONS FOR ONE MISSING PERSON
  // Lets the frontend check "did I already submit on this case"
  // before showing the submit form, instead of relying on the
  // self-submission/duplicate error at create time. Owner-scoped,
  // not public — no cache.
  // ─────────────────────────────────────────────

  async findMineForMissingPerson(userId: string, missingPersonId: string) {
    return this.prisma.informationSubmission.findMany({
      where: { userId, missingPersonId },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string, userId: string) {
    const submission = await this.prisma.informationSubmission.findUnique({
      where: { id },
      include: {
        missingPerson: {
          select: { id: true, personType: true, name: true, status: true },
        },
      },
    });

    if (!submission) {
      throw new NotFoundException('information_submission_not_found');
    }

    if (submission.userId !== userId) {
      throw new ForbiddenException('not_authorized');
    }

    return submission;
  }

  // ─────────────────────────────────────────────
  // UPDATE — OWNER
  // Only while PENDING — never the REVIEWED status the public cache
  // holds — so no invalidation needed here.
  //
  // Media handling: diffs each media field present in the request
  // against what's currently on the row. Newly-added filepaths are
  // validated against MinIO before the write; filepaths dropped
  // from the new array are deleted from MinIO after the write
  // commits — same ordering discipline as PostService.updateMyPost.
  //
  // FIX (item #13): attachment counts checked against the merged
  // post-update media shape; mediaTotalBytes recomputed from the
  // previous total plus/minus added/removed files' sizes.
  //
  // FIX (audit review, item #1 — the big one for this method): this
  // method emitted NO audit row at all, success or failure, despite
  // being a write to reporter-submitted evidence. Every guard
  // (not_authorized, submission_not_editable_in_current_status,
  // no_fields_provided, media validation) now emits a FAILURE/DENIED
  // row before throwing, and a SUCCESS row is emitted after the
  // write commits.
  //
  // ⚠️ SIGNATURE CHANGE: takes the full CurrentUserDto instead of a
  // bare userId string, since resolving actorType needs the actor's
  // roles — same reasoning as create() above. Update the controller
  // to pass @CurrentUser().
  //
  // FIX (audit review, item #4): entityLabel added.
  //
  // FIX (audit review, item #5): media churn (added/removed counts,
  // new total) captured in metadata, same as
  // ReportService.update()/PostService's equivalent.
  // ─────────────────────────────────────────────

  async update(id: string, user: CurrentUserDto, data: UpdateInformationSubmissionDto) {
    const actorType = resolveActorType(this.getRoles(user));

    const existing = await this.prisma.informationSubmission.findUnique({ where: { id } });

    if (!existing) {
      throw new NotFoundException('information_submission_not_found');
    }

    const label = this.buildSubmissionLabel(existing);

    if (existing.userId !== user.id) {
      this.emitAudit({
        userId: user.id,
        targetUserId: existing.userId,
        actorType,
        action: AuditEventEnum.INFORMATION_SUBMISSION_UPDATED,
        outcome: AuditOutcome.DENIED,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: id,
        entityLabel: label,
        diff: { result: 'denied', reason: 'not_authorized' },
      });
      throw new ForbiddenException('not_authorized');
    }

    if (existing.status !== InformationStatus.PENDING) {
      this.emitAudit({
        userId: user.id,
        actorType,
        action: AuditEventEnum.INFORMATION_SUBMISSION_UPDATED,
        outcome: AuditOutcome.FAILURE,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: id,
        entityLabel: label,
        diff: {
          result: 'failure',
          reason: 'submission_not_editable_in_current_status',
          currentStatus: existing.status,
        },
      });
      throw new ForbiddenException('submission_not_editable_in_current_status');
    }

    const hasAnyField = Object.values(data).some((value) => value !== undefined);

    if (!hasAnyField) {
      this.emitAudit({
        userId: user.id,
        actorType,
        action: AuditEventEnum.INFORMATION_SUBMISSION_UPDATED,
        outcome: AuditOutcome.FAILURE,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: id,
        entityLabel: label,
        diff: { result: 'failure', reason: 'no_fields_provided' },
      });
      throw new BadRequestException('no_fields_provided');
    }

    const { added, removed } = this.diffMediaFields(existing, data);

    const merged: MediaBearing = {
      photo: data.photo ?? existing.photo,
      video: data.video ?? existing.video,
      audio: data.audio ?? existing.audio,
      pdf: data.pdf ?? existing.pdf,
      document: data.document ?? existing.document,
      other: data.other ?? existing.other,
    };

    let addedBytes = 0;
    let removedBytes = 0;
    let newTotalBytes = existing.mediaTotalBytes;

    try {
      this.assertAttachmentCounts(merged);

      const validatedAdded = await this.validateMediaFilesExist(added);
      addedBytes = validatedAdded.reduce((sum, v) => sum + v.size, 0);

      // Stat failure on a removed file just means 0 bytes credited back, not a blocker.
      const removedStats = await Promise.allSettled(
        removed.map((fp) => this.minioService.statObject(fp)),
      );
      removedBytes = removedStats.reduce(
        (sum, r) => sum + (r.status === 'fulfilled' ? r.value.size : 0),
        0,
      );

      newTotalBytes = Math.max(0, existing.mediaTotalBytes + addedBytes - removedBytes);
      this.assertTotalBytes(newTotalBytes);
    } catch (err) {
      this.emitAudit({
        userId: user.id,
        actorType,
        action: AuditEventEnum.INFORMATION_SUBMISSION_UPDATED,
        outcome: AuditOutcome.FAILURE,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: id,
        entityLabel: label,
        diff: {
          result: 'failure',
          reason: 'media_validation_failed',
          message: err instanceof Error ? err.message : String(err),
        },
      });
      throw err;
    }

    const updated = await this.prisma.informationSubmission.update({
      where: { id },
      data: {
        ...(data.information !== undefined ? { information: data.information } : {}),
        ...(data.location !== undefined ? { location: data.location } : {}),
        ...(data.photo !== undefined ? { photo: data.photo } : {}),
        ...(data.video !== undefined ? { video: data.video } : {}),
        ...(data.audio !== undefined ? { audio: data.audio } : {}),
        ...(data.pdf !== undefined ? { pdf: data.pdf } : {}),
        ...(data.document !== undefined ? { document: data.document } : {}),
        ...(data.other !== undefined ? { other: data.other } : {}),
        mediaTotalBytes: newTotalBytes,
      },
    });

    // Delete only after the write commits, so a failed write never strands an orphan reference.
    await this.deleteMediaFiles(removed);

    this.emitAudit({
      userId: user.id,
      actorType,
      action: AuditEventEnum.INFORMATION_SUBMISSION_UPDATED,
      entity: 'InformationSubmission',
      entityId: updated.id,
      entityLabel: this.buildSubmissionLabel(updated),
      diff: { result: 'success' },
      metadata: {
        mediaAdded: added.length,
        mediaRemoved: removed.length,
        mediaTotalBytes: newTotalBytes,
      },
    });

    return updated;
  }

  // ─────────────────────────────────────────────
  // DELETE — OWNER
  // Only while PENDING — never REVIEWED — so no cache invalidation
  // needed here either, same reasoning as update() above.
  //
  // Deletes the DB row, then removes every attached media object
  // from MinIO — once the row referencing them is gone, an orphaned
  // object in the bucket serves no purpose. Same ordering as
  // PostService.deleteMyPost.
  //
  // FIX (audit review, item #1): both guards (not_authorized,
  // only_pending_submissions_can_be_deleted) threw with no row. Now
  // emit DENIED/FAILURE before throwing.
  //
  // FIX (audit review, item #4): entityLabel added — built before the
  // delete, since the row (and the label's source data) won't exist
  // afterward.
  //
  // FIX (audit review, item #5): count of media objects removed
  // wasn't captured anywhere — added to metadata.
  // ─────────────────────────────────────────────

  async remove(id: string, user: CurrentUserDto) {
    const actorType = resolveActorType(this.getRoles(user));

    const existing = await this.prisma.informationSubmission.findUnique({ where: { id } });

    if (!existing) {
      throw new NotFoundException('information_submission_not_found');
    }

    const label = this.buildSubmissionLabel(existing);

    if (existing.userId !== user.id) {
      this.emitAudit({
        userId: user.id,
        targetUserId: existing.userId,
        actorType,
        action: AuditEventEnum.INFORMATION_SUBMISSION_DELETED,
        outcome: AuditOutcome.DENIED,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: id,
        entityLabel: label,
        diff: { result: 'denied', reason: 'not_authorized' },
      });
      throw new ForbiddenException('not_authorized');
    }

    if (existing.status !== InformationStatus.PENDING) {
      this.emitAudit({
        userId: user.id,
        actorType,
        action: AuditEventEnum.INFORMATION_SUBMISSION_DELETED,
        outcome: AuditOutcome.FAILURE,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: id,
        entityLabel: label,
        diff: {
          result: 'failure',
          reason: 'only_pending_submissions_can_be_deleted',
          currentStatus: existing.status,
        },
      });
      throw new ForbiddenException('only_pending_submissions_can_be_deleted');
    }

    await this.prisma.informationSubmission.delete({ where: { id } });

    const mediaFields = this.collectMediaFields(existing);
    await this.deleteMediaFiles(mediaFields);

    this.emitAudit({
      userId: user.id,
      actorType,
      action: AuditEventEnum.INFORMATION_SUBMISSION_DELETED,
      entity: 'InformationSubmission',
      entityId: id,
      entityLabel: label,
      diff: {
        previousStatus: existing.status,
        result: 'success',
      },
      metadata: {
        missingPersonId: existing.missingPersonId,
        mediaFilesRemoved: mediaFields.length,
      },
    });

    return { message: 'information_submission_deleted' };
  }

  // ─────────────────────────────────────────────
  // ADMIN — GET ALL (paginated, lightweight — no nested detail)
  // Admin-only — deliberately left uncached, same as
  // MissingPersonService.findAllForAdmin / PostService.findAll, so an
  // admin never acts on stale data.
  // ─────────────────────────────────────────────

  async findAllForAdmin(query: ListInformationSubmissionsQueryDto) {
    const page = query.page ?? 1;
    const limit = query.limit ?? 20;

    const where = { ...(query.status !== undefined ? { status: query.status } : {}) };

    const [data, total] = await this.prisma.$transaction([
      this.prisma.informationSubmission.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.informationSubmission.count({ where }),
    ]);

    return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  // Pulls the tipster's name and phone; not yet audited (needs an acting-admin param and enum member).
  async findOneForAdmin(id: string) {
    const submission = await this.prisma.informationSubmission.findUnique({
      where: { id },
      include: {
        user: { select: { id: true, name: true, phone: true } },
        missingPerson: true,
      },
    });

    if (!submission) {
      throw new NotFoundException('information_submission_not_found');
    }

    return submission;
  }

  // Admin dashboard stats: totals by status.
  async getStats() {
    const [total, byStatus] = await this.prisma.$transaction([
      this.prisma.informationSubmission.count(),
      this.prisma.informationSubmission.groupBy({
        by: ['status'],
        _count: { status: true },
        orderBy: { status: 'asc' },
      }),
    ]);

    const statusCounts = Object.fromEntries(
      Object.values(InformationStatus).map((status) => [status, 0]),
    ) as Record<InformationStatus, number>;

    for (const row of byStatus) {
      const rowCount = row._count as { status?: number } | undefined;
      statusCounts[row.status] = rowCount?.status ?? 0;
    }

    return {
      total,
      pending: statusCounts[InformationStatus.PENDING] ?? 0,
      underReview: statusCounts[InformationStatus.UNDER_REVIEW] ?? 0,
      reviewed: statusCounts[InformationStatus.REVIEWED] ?? 0,
      rejected: statusCounts[InformationStatus.REJECTED] ?? 0,
    };
  }

  // Flags PENDING/UNDER_REVIEW submissions older than the configured stale window.
  async findStalePending() {
    const staleHours = Number(
      this.configService.get<string>('INFORMATION_SUBMISSION_STALE_PENDING_HOURS') ??
        this.configService.get<string>('CONTENT_STALE_PENDING_HOURS') ??
        48,
    );
    const cutoff = new Date(Date.now() - staleHours * 60 * 60 * 1000);

    const submissions = await this.prisma.informationSubmission.findMany({
      where: {
        status: { in: [InformationStatus.PENDING, InformationStatus.UNDER_REVIEW] },
        createdAt: { lt: cutoff },
      },
      orderBy: { createdAt: 'asc' },
    });

    return submissions.map((s) => ({
      ...s,
      pendingHours: Math.floor((Date.now() - s.createdAt.getTime()) / (60 * 60 * 1000)),
    }));
  }

  async getHistory(id: string) {
    await this.findOneForAdmin(id);

    return this.prisma.auditLog.findMany({
      where: { entity: 'InformationSubmission', entityId: id },
      orderBy: { createdAt: 'asc' },
    });
  }

  // ─────────────────────────────────────────────
  // ADMIN — UPDATE STATUS
  // Only moves PENDING → UNDER_REVIEW — never REVIEWED — so no cache
  // invalidation needed here.
  //
  // FIX (audit review, item #1): the invalid-transition guard threw
  // with no row. Now emits FAILURE first.
  //
  // FIX (audit review, item #4): entityLabel added.
  //
  // NOTE: the submission.status === status branch stays a silent
  // no-op rather than an audited failure — unlike ReportService's
  // updateStatus, a same-status "transition" here isn't reachable
  // from more than one caller racing (there's exactly one legal
  // transition out of PENDING), so it's much more likely to be an
  // idempotent retry than a conflict worth surfacing.
  // ─────────────────────────────────────────────

  async updateStatus(admin: CurrentUserDto, id: string, status: InformationStatus) {
    const actorType = resolveActorType(this.getRoles(admin));

    const submission = await this.prisma.informationSubmission.findUnique({ where: { id } });

    if (!submission) {
      throw new NotFoundException('information_submission_not_found');
    }

    if (submission.status === status) {
      return submission;
    }

    const label = this.buildSubmissionLabel(submission);
    const allowedNext = this.ALLOWED_STATUS_TRANSITIONS[submission.status] ?? [];

    if (!allowedNext.includes(status)) {
      this.emitAudit({
        userId: admin.id,
        targetUserId: submission.userId,
        actorType,
        action: AuditEventEnum.INFORMATION_UNDER_REVIEW,
        outcome: AuditOutcome.FAILURE,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: id,
        entityLabel: label,
        diff: {
          result: 'failure',
          currentStatus: submission.status,
          attemptedStatus: status,
        },
      });
      throw new BadRequestException(`invalid_status_transition: ${submission.status} -> ${status}`);
    }

    const updated = await this.prisma.informationSubmission.update({
      where: { id },
      data: { status },
    });

    this.emitAudit({
      userId: admin.id,
      targetUserId: submission.userId,
      actorType,
      action: AuditEventEnum.INFORMATION_UNDER_REVIEW,
      entity: 'InformationSubmission',
      entityId: updated.id,
      entityLabel: label,
      diff: {
        previousStatus: submission.status,
        newStatus: updated.status,
        result: 'success',
      },
      metadata: { missingPersonId: submission.missingPersonId },
    });

    return updated;
  }

  // ─────────────────────────────────────────────
  // ADMIN — REVIEW (terminal decision)
  // Only valid from UNDER_REVIEW. reviewNote required on REJECTED.
  //
  // Cache: this is the ONLY method in the file that can move a
  // submission into REVIEWED — the sole status the public
  // findForMissingPerson() cache ever serves — so it's the only
  // place that needs to invalidate that cache. It's a plain
  // invalidation (not conditional on `status === REVIEWED`) purely
  // for readability, since REJECTED never appeared in the cache to
  // begin with; invalidating an entry that was never cached is a
  // cheap no-op, same reasoning MissingPersonService.updateStatus
  // gives for invalidating unconditionally on every transition.
  //
  // FIX (audit review, item #2): submissionOwnerId was buried inside
  // `diff`, which should describe the change to the submission's
  // status — the tipster whose submission this is about the actual
  // subject of an admin's terminal decision, so it's now the
  // top-level targetUserId instead.
  //
  // FIX (audit review, item #3): reviewNote is the reviewing admin's
  // actual human-written rationale (mandatory on rejection, optional
  // on approval) — it was previously only forwarded to the
  // notification event and never written to the audit trail at all.
  // Now promoted to the top-level reason column.
  //
  // FIX (audit review, item #1): all three guards
  // (invalid_review_status, invalid_status_transition,
  // review_note_required_for_rejection) threw with no row. Now emit
  // FAILURE first. The reviewer's roles are resolved up front so
  // these early emits have a real actorType rather than a guess.
  //
  // FIX (audit review, item #4): entityLabel added.
  //
  // FIX (audit review, item #5): missingPersonId added to metadata —
  // it was already in the notification payload but never in the
  // audit row itself.
  // ─────────────────────────────────────────────

  async review(
    id: string,
    status: InformationStatus,
    reviewNote: string | undefined,
    reviewer: CurrentUserDto,
  ) {
    const actorType = resolveActorType(this.getRoles(reviewer));

    const submission = await this.prisma.informationSubmission.findUnique({ where: { id } });

    if (!submission) {
      throw new NotFoundException('information_submission_not_found');
    }

    const label = this.buildSubmissionLabel(submission);

    if (status !== InformationStatus.REVIEWED && status !== InformationStatus.REJECTED) {
      this.emitAudit({
        userId: reviewer.id,
        targetUserId: submission.userId,
        actorType,
        action: AuditEventEnum.INFORMATION_REJECTED,
        outcome: AuditOutcome.FAILURE,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: id,
        entityLabel: label,
        diff: { result: 'failure', reason: 'invalid_review_status', attemptedStatus: status },
      });
      throw new BadRequestException('invalid_review_status');
    }

    const auditEventForStatus =
      status === InformationStatus.REVIEWED
        ? AuditEventEnum.INFORMATION_REVIEWED
        : AuditEventEnum.INFORMATION_REJECTED;

    if (submission.status !== InformationStatus.UNDER_REVIEW) {
      this.emitAudit({
        userId: reviewer.id,
        targetUserId: submission.userId,
        actorType,
        action: auditEventForStatus,
        outcome: AuditOutcome.FAILURE,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: id,
        entityLabel: label,
        diff: {
          result: 'failure',
          reason: 'invalid_status_transition',
          currentStatus: submission.status,
          attemptedStatus: status,
        },
      });
      throw new BadRequestException(`invalid_status_transition: ${submission.status} -> ${status}`);
    }

    if (status === InformationStatus.REJECTED && !reviewNote?.trim()) {
      this.emitAudit({
        userId: reviewer.id,
        targetUserId: submission.userId,
        actorType,
        action: auditEventForStatus,
        outcome: AuditOutcome.FAILURE,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: id,
        entityLabel: label,
        diff: { result: 'failure', reason: 'review_note_required_for_rejection' },
      });
      throw new BadRequestException('review_note_required_for_rejection');
    }

    // G21: REVIEWED is the terminal decision that makes a submission
    // eligible for RewardService.approveClaim(submissionId) — the step
    // that turns a tip into a payout. userId is nullable on
    // InformationSubmission (anonymous/USSD tips per SubmissionChannel),
    // and there is no other identifying field on the model yet
    // (contactPhone is proposed in the section-9 schema review but not
    // migrated), so an anonymous tip cannot currently be verified or paid.
    // Block REVIEWED rather than let it through and fail later, silently
    // or otherwise, inside RewardService.
    if (status === InformationStatus.REVIEWED && !submission.userId) {
      this.emitAudit({
        userId: reviewer.id,
        targetUserId: submission.userId,
        actorType,
        action: auditEventForStatus,
        outcome: AuditOutcome.FAILURE,
        severity: AuditSeverity.WARNING,
        entity: 'InformationSubmission',
        entityId: id,
        entityLabel: label,
        diff: {
          result: 'failure',
          reason: 'finder_not_verifiable',
          channel: submission.channel,
        },
        metadata: { missingPersonId: submission.missingPersonId },
      });
      throw new BadRequestException('finder_not_verifiable');
    }

    const updated = await this.prisma.informationSubmission.update({
      where: { id },
      data: {
        status,
        ...(reviewNote !== undefined ? { reviewNote } : {}),
      },
    });

    await this.cache.invalidateInformationSubmissionList(submission.missingPersonId);

    this.emitAudit({
      userId: reviewer.id,
      targetUserId: submission.userId,
      actorType,
      action: auditEventForStatus,
      entity: 'InformationSubmission',
      entityId: updated.id,
      entityLabel: label,
      reason: reviewNote ?? null,
      diff: {
        previousStatus: submission.status,
        newStatus: status,
        result: 'success',
      },
      metadata: { missingPersonId: submission.missingPersonId },
    });

    const notificationEvent =
      status === InformationStatus.REVIEWED
        ? NotificationEventEnum.INFORMATION_SUBMISSION_REVIEWED
        : NotificationEventEnum.INFORMATION_SUBMISSION_REJECTED;

    this.eventEmitter.emit(notificationEvent, {
      userId: submission.userId,
      informationSubmissionId: updated.id,
      missingPersonId: submission.missingPersonId,
      status: updated.status,
      reviewNote,
    });

    return updated;
  }
}