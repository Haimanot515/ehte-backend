import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';

import { PrismaService } from 'src/prisma/prisma.service';
import { RolesEnum } from '../enums/roles.enum';

@Injectable()
export class UserSeeder {
  private readonly logger = new Logger(UserSeeder.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
  ) {}

  async run(): Promise<void> {
    const rawPhone = this.config.get<string>('USER_PHONE', '+251900000000');

    const phone = rawPhone.trim();

    const name = this.config.get<string>('USER_NAME', 'Ehte Test User');

    const password = this.config.get<string>('USER_PASSWORD', 'P@ssw0rd');

    const existingUser = await this.prisma.user.findUnique({
      where: {
        phone,
      },
    });

    if (existingUser) {
      return;
    }

    const role = await this.prisma.role.findUnique({
      where: {
        name: RolesEnum.USER,
      },
    });

    if (!role) {
      throw new Error(
        `Required role "${RolesEnum.USER}" was not found. Ensure RolesSeeder runs before UserSeeder.`,
      );
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await this.prisma.user.create({
      data: {
        name,
        phone,
        passwordHash: hashedPassword,

        // The seeded USER is already verified.
        // Therefore login() can be used immediately.
        isPhoneVerified: true,
        isActive: true,
      },
    });

    await this.prisma.userRole.create({
      data: {
        userId: user.id,
        roleId: role.id,
      },
    });

    this.logger.log(`Seeded initial USER account: ${phone} / ${password}`);
  }
}
