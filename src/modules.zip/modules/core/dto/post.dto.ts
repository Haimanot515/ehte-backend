import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  MinLength,
} from 'class-validator';

import { Transform, Type } from 'class-transformer';

import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

import { PostStatus, PostType } from '@prisma/client';

export class CreatePostDto {
  @ApiPropertyOptional({ maxLength: 200, example: 'Community safety walk this Saturday' })
  @IsOptional()
  @IsString()
  @MaxLength(200)
  title?: string;

  @ApiProperty({ minLength: 3, example: 'Details about the incident or awareness message...' })
  @IsString()
  @MinLength(3)
  content!: string;

  @ApiProperty({ enum: PostType, example: PostType.AWARENESS })
  @IsEnum(PostType)
  type!: PostType;

  // Flags content involving a child, driving the additional-review
  // gate required by PRD §32. Optional so existing clients that
  // don't send it keep working (defaults to false in the service).
  @ApiPropertyOptional({
    default: false,
    description: 'Triggers additional child-safety review (PRD §32).',
  })
  @IsOptional()
  @IsBoolean()
  involvesChild?: boolean;

  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  photo?: string[];

  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  video?: string[];

  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  audio?: string[];

  // NOTE: MEDIA_ALLOWED_MIME_TYPES must include application/pdf for
  // this field to be usable — PostService.validateMediaFilesExist()
  // rejects any attached object whose content-type isn't on that list.
  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  pdf?: string[];

  // NOTE: same as pdf above — whatever document content-types you
  // intend to accept must be listed in MEDIA_ALLOWED_MIME_TYPES.
  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  document?: string[];

  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  other?: string[];

  // ─────────────────────────────────────────
  // RE-AUTHENTICATION
  //
  // Verified and stripped by ReauthGuard before this DTO's data
  // reaches PostService.create() — never persisted or returned.
  // Optional here since it can instead be supplied via the
  // X-Reauth-Credential header; the guard accepts either.
  // Only relevant on POST /posts (create), which is the only
  // CreatePostDto-based endpoint gated by @RequireReauthentication().
  // ─────────────────────────────────────────
  @ApiPropertyOptional({
    description:
      'Account password (or Discreet Mode passcode, if enabled) confirming this sensitive action. Optional here if provided instead via the X-Reauth-Credential header.',
    example: 'StrongPassword123',
  })
  @IsOptional()
  @IsString()
  credential?: string;
}

// ─────────────────────────────────────────────
// Owner edit, PATCH /posts/me/:id.
// Allowed only while DRAFT or CHANGES_REQUESTED
// (enforced in PostService, not here).
// ─────────────────────────────────────────────

export class UpdatePostDto {
  @ApiPropertyOptional({ maxLength: 200 })
  @IsOptional()
  @IsString()
  @MaxLength(200)
  title?: string;

  @ApiPropertyOptional({ minLength: 3 })
  @IsOptional()
  @IsString()
  @MinLength(3)
  content?: string;

  @ApiPropertyOptional({ enum: PostType })
  @IsOptional()
  @IsEnum(PostType)
  type?: PostType;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  involvesChild?: boolean;

  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  photo?: string[];

  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  video?: string[];

  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  audio?: string[];

  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  pdf?: string[];

  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  document?: string[];

  @ApiPropertyOptional({
    type: [String],
    description: 'MinIO filepaths returned by POST /media/upload-url',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  other?: string[];
}

// ─────────────────────────────────────────────
// Admin "Request changes", PRD §24.
// PATCH /posts/:id/request-changes
// ─────────────────────────────────────────────

export class RequestPostChangesDto {
  @ApiProperty({ minLength: 3, example: 'Please blur the second photo before resubmitting.' })
  @IsString()
  @MinLength(3)
  message!: string;
}

// ─────────────────────────────────────────────
// Admin approve body. childSafetyConfirmed is
// required (enforced in PostService.approve)
// whenever the post has involvesChild = true.
//
// NOTE (dual-control fix, item #10): a single true
// here is no longer sufficient on its own to approve
// a child-involving post. The FIRST admin to send
// childSafetyConfirmed=true only records their own
// confirmation (childSafetyFirstConfirmedByUserId);
// the post only actually moves to APPROVED once a
// SECOND, different admin also sends
// childSafetyConfirmed=true. See
// PostService.ensureChildSafetySatisfied().
// ─────────────────────────────────────────────

export class ApprovePostDto {
  @ApiPropertyOptional({
    description:
      'Required (must be true) when the post has involvesChild = true (PRD §32). Two DIFFERENT admins must each send true before the post actually becomes APPROVED.',
  })
  @IsOptional()
  @IsBoolean()
  childSafetyConfirmed?: boolean;
}

// ─────────────────────────────────────────────
// Admin reject body, PRD §24 + §40 (Transparency).
// ─────────────────────────────────────────────

export class RejectPostDto {
  @ApiProperty({ minLength: 3, example: 'Content does not comply with platform guidelines.' })
  @IsString()
  @MinLength(3)
  reason!: string;
}

// ─────────────────────────────────────────────
// Admin "official Post" creation, PRD §13.
// Mirrors ApprovePostDto: when involvesChild is true
// AND publishImmediately is true (the straight-to-
// APPROVED path), childSafetyConfirmed must be
// explicitly true. Enforced in PostService.createOfficial.
//
// NOTE: the dual-control rule (#10) is NOT re-applied
// here on purpose — createOfficial is already gated
// behind PermissionsEnum.POST_CREATE_OFFICIAL, a
// higher-trust action than the normal review queue.
// If you want dual-control here too, route
// publishImmediately+involvesChild posts through the
// normal PENDING → approve() path instead.
// ─────────────────────────────────────────────

export class AdminCreatePostDto extends CreatePostDto {
  // If true (default), the post is created directly as APPROVED,
  // ready for an explicit /publish call. If false, it is created
  // as PENDING and goes through the normal approve/reject/
  // request-changes flow like a user post.
  @ApiPropertyOptional({
    default: true,
    description:
      'If true, skips straight to APPROVED. If false, goes through normal PENDING review.',
  })
  @IsOptional()
  @IsBoolean()
  publishImmediately?: boolean;

  // Required when involvesChild is true AND publishImmediately
  // is true. Not required on the PENDING path, since that path
  // still goes through approve()'s own gate later.
  @ApiPropertyOptional({
    description:
      'Required (must be true) when involvesChild is true and publishImmediately is true.',
  })
  @IsOptional()
  @IsBoolean()
  childSafetyConfirmed?: boolean;
}

// ─────────────────────────────────────────────
// Admin list filters/pagination for GET /posts,
// matching AdminReportQueryDto's shape.
//
// involvesChild uses a string-aware @Transform
// (the naive @Type(() => Boolean) would turn the
// string "false" into `true` via JS's Boolean()).
// ─────────────────────────────────────────────

export class AdminPostQueryDto {
  @ApiPropertyOptional({ enum: PostStatus })
  @IsOptional()
  @IsEnum(PostStatus)
  status?: PostStatus;

  @ApiPropertyOptional({ enum: PostType })
  @IsOptional()
  @IsEnum(PostType)
  type?: PostType;

  @ApiPropertyOptional({ type: Boolean })
  @IsOptional()
  @Transform(({ value }) => value === 'true' || value === true)
  @IsBoolean()
  involvesChild?: boolean;

  @ApiPropertyOptional({ description: 'Filter by post author (userId).' })
  @IsOptional()
  @IsString()
  authorId?: string;

  @ApiPropertyOptional({ default: 1, minimum: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number = 1;

  @ApiPropertyOptional({ default: 20, minimum: 1, maximum: 100 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  limit?: number = 20;
}

// ─────────────────────────────────────────────
// Pagination for GET /posts/published. PRD §30
// (Low Bandwidth Requirements).
// ─────────────────────────────────────────────

export class PublishedPostsQueryDto {
  @ApiPropertyOptional({ enum: PostType })
  @IsOptional()
  @IsEnum(PostType)
  type?: PostType;

  @ApiPropertyOptional({ default: 1, minimum: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number = 1;

  @ApiPropertyOptional({ default: 20, minimum: 1, maximum: 100 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  limit?: number = 20;
}

// ─────────────────────────────────────────────
// PATCH /posts/:id/status body. Routed through a
// real DTO with @IsEnum so no unvalidated string
// reaches Prisma.
// ─────────────────────────────────────────────

export class UpdatePostStatusDto {
  @ApiProperty({ enum: PostStatus })
  @IsEnum(PostStatus)
  status!: PostStatus;

  // Required whenever the target status is APPROVED or
  // PUBLISHED and the post has involvesChild = true. Closes
  // the bypass where this generic endpoint could skip
  // approve()'s child-safety gate entirely. Same dual-control
  // rule as ApprovePostDto applies (#10).
  @ApiPropertyOptional({
    description:
      'Required (must be true) when moving an involvesChild post to APPROVED or PUBLISHED. Two DIFFERENT admins must each send true.',
  })
  @IsOptional()
  @IsBoolean()
  childSafetyConfirmed?: boolean;
}

// ─────────────────────────────────────────────
// Bulk admin actions (item #8).
// Low-risk posts only: any id whose post has
// involvesChild = true is skipped and reported back
// as requiring individual review, never silently
// bulk-approved.
// ─────────────────────────────────────────────

export class BulkPostIdsDto {
  @ApiProperty({ type: [String], description: 'Post ids to act on in one request.' })
  @IsArray()
  @IsString({ each: true })
  @MinLength(1, { each: true })
  ids!: string[];
}

export class BulkRejectPostDto extends BulkPostIdsDto {
  @ApiProperty({ minLength: 3, example: 'Content does not comply with platform guidelines.' })
  @IsString()
  @MinLength(3)
  reason!: string;
}
